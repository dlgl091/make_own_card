from django.shortcuts import get_object_or_404, render, redirect


# Create your views here.
def index(request):
    #return HttpResponse("Hello, world. You're at the polls index.")
    return render(request, 'polls/index.html')


def result(request):
    return render(request, 'polls/result.html')
def step_1(request):
    return render(request, 'polls/step_1.html')
def step_2(request):
    if request.method == 'GET':

        id = request.GET.get('mode')
        if id:
            id1 = id + "_1_img.png"
            id2 = id + "_2_img.png"
            data = {
                'img1': id1,
                'img2': id2,
            }
            return render(request, 'polls/step_2.html', data)
        else:
                # 'mode' 파라미터가 없으면 메인 페이지로 리다이렉트
                return redirect('polls:index')  # URL 패턴 이름 사용
    else:
        # GET 요청이 아닌 경우에도 메인 페이지로 리다이렉트
        return redirect('polls:index')